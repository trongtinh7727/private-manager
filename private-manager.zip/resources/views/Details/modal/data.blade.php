<tr>
    <td class="text-center">1</td>
    <td>Danh mục</td>
    <td>Điểm vào</td>
    <td>Điểm ra</td>
    <td>Điểm lời mới</td>
    <td>Điểm lời cũ</td>
    <td>TC Thành Tiền</td>
    <td class="text-right">€ 89,241</td>
    "<td class="td-actions text-right">
        <button type="button" rel="tooltip" class="btn btn-info btn-round" data-original-title="" title="">
            <i class="material-icons">person</i>
        </button>
        <button type="button" rel="tooltip" class="btn btn-success btn-round" data-original-title="" title="">
            <i class="material-icons">edit</i>
        </button>
        <button type="button" rel="tooltip" class="btn btn-danger btn-round" data-original-title="" title="">
            <i class="material-icons">close</i>
        </button>
    </td>"
</tr>
